<?php
declare(strict_types=1);

namespace FlujosDimension\Services;

/**
 * @deprecated Use CallService instead.
 */
class RingoverService extends CallService {}
