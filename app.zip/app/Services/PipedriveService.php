<?php
declare(strict_types=1);

namespace FlujosDimension\Services;

/**
 * @deprecated Use CRMService instead.
 */
class PipedriveService extends CRMService {}
