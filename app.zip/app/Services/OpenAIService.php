<?php
declare(strict_types=1);

namespace FlujosDimension\Services;

/**
 * @deprecated Use AnalysisService instead.
 */
class OpenAIService extends AnalysisService {}
