<?php
declare(strict_types=1);

/**
 * Panel de Administración — Front Controller
 *
 * Este índice centraliza el ruteo del panel (?action=...)
 * e integra el Gestor de JWS/JWT (generar par RSA, importar PEM,
 * rotar KID activo y servir JWKS) sin require_once a rutas físicas,
 * apoyándose en el autoloader PSR-4 de Composer.
 *
 * Requisitos:
 *  - composer.json con: "autoload": { "psr-4": { "FlujosDimension\\": "app/" } }
 *  - Clases:
 *      app/Controllers/JwtController.php       (namespace FlujosDimension\Controllers)
 *      app/Services/JwtKeyService.php          (namespace FlujosDimension\Services)
 *  - Vistas opcionales:
 *      admin/views/dashboard.php
 *      admin/views/env_editor.php
 *
 * Rutas soportadas:
 *  - ?action=dashboard      → dashboard del panel (si no existe, fallback)
 *  - ?action=env            → editor de .env (si existe la vista)
 *  - ?action=jwt            → UI del gestor JWS/JWT
 *  - ?action=jwt.generate   → (POST) generar y activar un par RSA
 *  - ?action=jwt.import     → (POST) importar PEMs y activar
 *  - ?action=jwt.rotate     → (POST) rotar KID activo
 *  - ?action=jwt.jwks       → (GET) endpoint JWKS público
 */

ini_set('display_errors', '0');          // en producción: no mostrar errores
ini_set('log_errors', '1');              // registrar errores en el log del servidor
error_reporting(E_ALL);

// ------------------------------------------------------------
//  Autoload Composer (PSR-4) y constantes de ruta
// ------------------------------------------------------------
$PROJECT_ROOT = dirname(__DIR__);        // /ruta/absoluta/al/proyecto
$VENDOR_AUTO  = $PROJECT_ROOT . '/vendor/autoload.php';

if (!file_exists($VENDOR_AUTO)) {
    http_response_code(500);
    echo "Falta vendor/autoload.php. Ejecuta 'composer install' en el proyecto.";
    exit;
}
require_once $VENDOR_AUTO;

// (Opcional) Cargar .env si usas vlucas/phpdotenv
if (class_exists(\Dotenv\Dotenv::class)) {
    try {
        \Dotenv\Dotenv::createImmutable($PROJECT_ROOT)->safeLoad();
    } catch (\Throwable $e) {
        // noop: no convertimos esto en fatal; el panel puede seguir
    }
}

// Arrancar sesión
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

// Si tienes guard o middleware de autenticación, respétalo:
if (function_exists('requireLogin')) {
    requireLogin();
}

// ------------------------------------------------------------
//  Imports (PSR-4): Controladores del panel
// ------------------------------------------------------------
use FlujosDimension\Controllers\JwtController;

// Instancia del controlador JWT. Le pasamos basePath y adminPath
$jwt = new JwtController($PROJECT_ROOT, __DIR__);

// ------------------------------------------------------------
//  Helpers de render y respuestas
// ------------------------------------------------------------
/**
 * Renderiza una vista PHP simple, si existe.
 * @param string $viewPath Ruta absoluta a la vista.
 * @param array  $vars     Variables disponibles en la vista.
 */
function render_view(string $viewPath, array $vars = []): void {
    extract($vars, EXTR_SKIP);
    if (file_exists($viewPath)) {
        include $viewPath;
    } else {
        echo "<!doctype html><meta charset='utf-8'><title>Vista no encontrada</title>";
        echo "<h1>Vista no encontrada</h1><p>" . htmlspecialchars($viewPath, ENT_QUOTES) . "</p>";
    }
}

/**
 * Envía una respuesta 405 con texto simple.
 */
function method_not_allowed(): void {
    http_response_code(405);
    header('Content-Type: text/plain; charset=utf-8');
    echo "Método no permitido";
}

/**
 * (Opcional) Log de errores del panel, si tu proyecto tiene un Logger PSR-3.
 */
function admin_log_error(\Throwable $e): void {
    if (class_exists(\FlujosDimension\Core\Logger::class)) {
        try {
            $logDir = dirname(__DIR__) . '/storage/logs';
            $logger = new \FlujosDimension\Core\Logger($logDir, \Psr\Log\LogLevel::ERROR);
            $logger->error('Admin error', ['exception' => $e]);
        } catch (\Throwable $ignored) {}
    }
}

// ------------------------------------------------------------
//  Router sencillo por query-string (?action=...)
// ------------------------------------------------------------
$action = $_GET['action'] ?? 'dashboard';

try {
    switch ($action) {

        // --------------------------------------------------------
        // Dashboard del panel
        // --------------------------------------------------------
        case 'dashboard': {
            $dashboardView = __DIR__ . '/views/dashboard.php';
            if (file_exists($dashboardView)) {
                render_view($dashboardView, [
                    // Pasa aquí cualquier variable que tu dashboard necesite
                ]);
            } else {
                // Fallback minimalista si no existe la vista
                echo "<!doctype html><meta charset='utf-8'><title>Admin</title>";
                echo "<h1>Panel de administración</h1>";
                echo "<ul>";
                echo "<li><a href='?action=env'>Editar .env</a></li>";
                echo "<li><a href='?action=jwt'>🔐 Gestor JWS/JWT</a></li>";
                echo "</ul>";
            }
            break;
        }

        // --------------------------------------------------------
        // Editor de .env
        // --------------------------------------------------------
        case 'env': {
            $envView = __DIR__ . '/views/env_editor.php';
            render_view($envView, []);
            break;
        }

        // --------------------------------------------------------
        // Gestor JWS/JWT — UI principal
        // --------------------------------------------------------
        case 'jwt': {
            $jwt->index();
            break;
        }

        // Generar y activar nuevo par RSA
        case 'jwt.generate': {
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                method_not_allowed(); break;
            }
            $jwt->generate();   // redirige a ?action=jwt
            break;
        }

        // Importar PEM y activar
        case 'jwt.import': {
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                method_not_allowed(); break;
            }
            $jwt->importPem();  // redirige a ?action=jwt
            break;
        }

        // Rotar KID activo
        case 'jwt.rotate': {
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                method_not_allowed(); break;
            }
            $jwt->rotate();     // redirige a ?action=jwt
            break;
        }

        // Servir JWKS (público). Si prefieres, expón esto desde /public
        case 'jwt.jwks': {
            $jwt->serveJwks();
            break;
        }

        // --------------------------------------------------------
        // 404 por defecto
        // --------------------------------------------------------
        default: {
            http_response_code(404);
            echo "<!doctype html><meta charset='utf-8'><title>404</title>";
            echo "<h1>404 - Acción no encontrada</h1>";
            echo "<p>Acción: <code>" . htmlspecialchars($action, ENT_QUOTES) . "</code></p>";
            echo "<p><a href='/admin/?action=dashboard'>&larr; Volver al panel</a></p>";
            break;
        }
    }

} catch (\Throwable $e) {
    // Manejo de errores centralizado para el panel
    admin_log_error($e);
    http_response_code(500);
    $msg = htmlspecialchars($e->getMessage(), ENT_QUOTES);
    echo "<!doctype html><meta charset='utf-8'><title>Error</title>";
    echo "<h1>Error en Admin</h1>";
    echo "<pre>{$msg}</pre>";
}
